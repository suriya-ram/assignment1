package daos;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import beans.Person;

@Repository
public class PersonDAO {
	
	@Autowired
	JdbcTemplate jt;
	
	public List<Person> getAll(){
		return jt.query("select * from person", new MapperClass());
	}
	
	public Person findById(int id) {
		return jt.queryForObject("select * from person where id=?", new MapperClass(), new Object[] {id});
	}
	
	public List<Person> findByName(String name) {
		return jt.query("select * from person where name=?", new MapperClass(), new Object[] {name});
	}
	
	public int deleteById(int id) {
		return jt.update("delete from person where id=?", new Object[] {id});
	}
}
