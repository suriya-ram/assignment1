package com.nandha.database_tutorial;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import beans.Person;
import daos.PersonDAO;

@SpringBootApplication
@ComponentScan({"daos"})
public class DatabaseTutorialApplication implements CommandLineRunner{
	
	@Autowired
	PersonDAO pdao;

	public static void main(String[] args) {
		SpringApplication.run(DatabaseTutorialApplication.class, args);
	}
	
	public static void printList(List<Person> persons) {
		for(Person p: persons) {
			System.out.println(p);
		}
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println(pdao.getAll());
		System.out.println(pdao.findById(10002));
	
		List<Person> persons = pdao.findByName("Nandha");
		System.out.println("The matches mathced with Nandha are: ");
		printList(persons);
		
		//deleting a record
		int recordsDeleted = pdao.deleteById(10004);
		System.out.println("The no of records deleted are: " + recordsDeleted);
		
		System.out.println(pdao.getAll());
	}

}
