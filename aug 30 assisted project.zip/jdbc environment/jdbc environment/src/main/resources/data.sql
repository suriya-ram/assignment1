create table person(
	id int not null,
	name varchar(30) not null,
	age int not null,
	location varchar(50),
	primary key(id)
);

insert into person(
id, name, age, location
) 
values (
10001, 'Nandha', 22, 'Tamil Nadu'
);

insert into person(
id, name, age, location
) 
values (
10002, 'Kavitha', 42, 'Tamil Nadu'
);

insert into person(
id, name, age, location
) 
values (
10003, 'Velumani', 52, 'Tamil Nadu'
);

insert into person(
id, name, age, location
) 
values (
10004, 'Kumar', 12, 'Canada'
);

insert into person(
id, name, age, location
) 
values (
10005, 'Nandha', 22, 'New York'
);


