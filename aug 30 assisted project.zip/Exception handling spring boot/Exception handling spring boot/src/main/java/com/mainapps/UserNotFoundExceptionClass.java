package com.mainapps;

public class UserNotFoundExceptionClass extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
