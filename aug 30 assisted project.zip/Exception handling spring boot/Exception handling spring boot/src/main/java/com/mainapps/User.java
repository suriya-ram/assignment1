package com.mainapps;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;

@Entity
@NamedQuery(name = "find_all_users", query = "select u from User u")
public class User {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	private String name;
	private String feedback;
	

	public User() {
	}

	public User(int id, String name, String feedback) {
		this.id = id;
		this.name = name;
		this.feedback = feedback;
	}
	
	public User(String name, String feedback) {
		this.name = name;
		this.feedback = feedback;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", feedback=" + feedback + "]";
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getFeedback() {
		return feedback;
	}


	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

}
