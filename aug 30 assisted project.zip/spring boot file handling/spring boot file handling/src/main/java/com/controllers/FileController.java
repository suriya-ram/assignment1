package com.controllers;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class FileController {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@RequestMapping(value = "/upload", method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	@ResponseBody
	public String uploadFile(@RequestParam("fileinfo") MultipartFile userFile) {
		System.out.println("working");
		String result = null;
		
		try {
			File convertedFile = new File("C:/Users/Nandhakumar/Desktop/temp/"+ userFile.getOriginalFilename());
			
			convertedFile.createNewFile();
			
			FileOutputStream fout = new FileOutputStream(convertedFile);
			fout.write(userFile.getBytes());
			fout.close();
			
			result = "File uploaded successfully 😍";
		}catch(IOException e) {
			result = "Error message: "+ e.getMessage();
		}
		return result;
	}
	
	
	@RequestMapping(value = "/download", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity downloadFile(@RequestParam("file-name") String filename, HttpServletRequest req, HttpServletResponse res) {
		
		if(filename.equals("")) {
			RequestDispatcher rd = req.getRequestDispatcher("index.html");
			try {
				return ResponseEntity.ok().body("Enter a valid name");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
			logger.info("The dowmload file is" + filename);
			Path path = Paths.get("C:/Users/Nandhakumar/Desktop/temp/"+ filename);
			Resource resource = null;
			
			try {
				resource = new UrlResource(path.toUri());
			}catch (MalformedURLException e) {
	    		e.printStackTrace();
	    	}
			
			return ResponseEntity.ok()
					.contentType(MediaType.parseMediaType("application/text"))
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
					.body(resource);
		}
		
		
}
