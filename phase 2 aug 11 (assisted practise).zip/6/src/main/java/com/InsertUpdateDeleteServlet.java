package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class InsertUpdateDeleteServlet
 */
public class InsertUpdateDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		
		Connection con = DBConnector.getConnection();
		Statement stm = null;
		try {
			
			stm = con.createStatement();
			//insert record
			stm.executeUpdate("insert products(product_name, stock) values ('eggs', 20)");
			out.println("Record inserted successfully\n");
			
			ResultSet result = stm.executeQuery("select * from products");
			
			while(result.next())
				out.println(result.getInt("product_id")+" "+result.getString("product_name")+ " "+ result.getInt("stock")+'\n');
			
			//update record
			stm.executeUpdate("update products set stock=11 where product_name='eggs'");
			out.println("Record updated successfully\n");
			
			result = stm.executeQuery("select * from products");
			
			while(result.next())
				out.println(result.getInt("product_id")+" "+result.getString("product_name")+ " "+ result.getInt("stock")+'\n');
			
			//delete record
			stm.executeUpdate("delete from products where product_name='eggs'");
			out.println("Record deleted successfully\n");
			
			//printing the table
			result = stm.executeQuery("select * from products");
			
			while(result.next())
				out.println(result.getInt("product_id")+" "+result.getString("product_name")+ " "+ result.getInt("stock"));
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				stm.close();
				con.close();
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
	}

}
